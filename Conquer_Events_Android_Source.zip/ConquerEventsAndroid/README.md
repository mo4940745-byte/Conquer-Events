# Conquer Events Android starter
Black/blue native Android starter with event selection and local notification scheduling in Africa/Cairo timezone.

IMPORTANT LIMITATIONS:
- This is source code, not an APK. It has not been compiled or tested on a physical Android device.
- Current reminder scheduler schedules one next reminder per event; the app must be opened after reminders to refresh next occurrences. A production build should use a robust rescheduling worker/receiver and exact-alarm permission flow.
- Android 13+ notification permission must be granted. Exact alarm access may require user approval in Android settings on Android 12+.
- Android 14+ background restrictions and OEM battery optimizations need real-device testing.
- The provided event schedule is an initial transcription and must be verified against the server's current official schedule. All-day/time-range events and summon-based Soul are not given fixed reminders.
- iOS requires a separate native build and Apple signing/distribution; this Android project does not create an iPhone app.
Build with Android Studio / Gradle, then create a signed APK.
