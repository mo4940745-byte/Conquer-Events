package com.conquerevents.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Event(val name:String,val days:Any?,val time:String,val entry:String,val type:String,val note:String?)
class MainActivity: Activity() {
 private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }
 private val events by lazy { loadEvents() }
 private val blue=Color.rgb(83,164,255); private val bg=Color.rgb(8,13,22); private val panel=Color.rgb(20,30,46)
 override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg
  createChannel(); requestPermissionsIfNeeded(); render()
 }
 private fun loadEvents():List<Event>{
  val raw=assets.open("events.json").bufferedReader().use{it.readText()}; val a=JSONArray(raw)
  return (0 until a.length()).map{val o=a.getJSONObject(it); val d=o.opt("days"); Event(o.getString("name"),d,o.getString("time"),o.getString("entry"),o.getString("type"),o.optString("note").ifBlank{null})}
 }
 private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){ val ch=NotificationChannel("events","Event reminders",NotificationManager.IMPORTANCE_HIGH).apply{description="Conquer event reminders with sound"; enableVibration(true)}; getSystemService(NotificationManager::class.java).createNotificationChannel(ch)}}
 private fun requestPermissionsIfNeeded(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),44) }
 private fun render(){
  val root=LinearLayout(this).apply{orientation=1;setPadding(18,22,18,18);setBackgroundColor(bg)}
  val title=TextView(this).apply{text="⚔ CONQUER EVENTS";textSize=24f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.DEFAULT_BOLD}
  root.addView(title); root.addView(TextView(this).apply{text="EVENT SCHEDULE  •  EGYPT TIME";textSize=12f;setTextColor(blue);setPadding(0,6,0,18)})
  val info=TextView(this).apply{text="Choose your events. You’ll receive a sound reminder 5 minutes before each scheduled start.";setTextColor(Color.LTGRAY);textSize=13f;setPadding(14,14,14,14);setBackgroundColor(panel)}
  root.addView(info)
  val buttons=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER;setPadding(0,12,0,12)}
  val all=Button(this).apply{text="SELECT ALL";setOnClickListener{events.indices.forEach{prefs.edit().putBoolean("e$it",true).apply()};scheduleAll();render()}}
  val none=Button(this).apply{text="CLEAR";setOnClickListener{events.indices.forEach{prefs.edit().putBoolean("e$it",false).apply()};cancelAll();render()}}
  buttons.addView(all,LinearLayout.LayoutParams(0,-2,1f));buttons.addView(none,LinearLayout.LayoutParams(0,-2,1f));root.addView(buttons)
  val scroll=ScrollView(this); val list=LinearLayout(this).apply{orientation=1}
  var last=""
  events.forEachIndexed{idx,e->
   if(e.type!=last){last=e.type;list.addView(TextView(this).apply{text=last.uppercase(Locale.US);textSize=13f;setTextColor(blue);setPadding(2,18,0,7)})}
   val row=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL;setPadding(10,9,10,9);setBackgroundColor(panel)}
   val cb=CheckBox(this).apply{buttonTintList=android.content.res.ColorStateList.valueOf(blue);isChecked=prefs.getBoolean("e$idx",true);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("e$idx",v).apply();scheduleEvent(idx,e,v)}}
   val col=LinearLayout(this).apply{orientation=1}
   col.addView(TextView(this).apply{text=e.name;setTextColor(Color.WHITE);textSize=15f})
   col.addView(TextView(this).apply{text="${dayLabel(e.days)} • ${e.entry}";setTextColor(Color.LTGRAY);textSize=11f})
   row.addView(cb);row.addView(col,LinearLayout.LayoutParams(0,-2,1f));row.addView(TextView(this).apply{text=e.time;setTextColor(blue);textSize=13f})
   val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=5;list.addView(row,lp)
  }
  scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root)
  if(prefs.getBoolean("first",true)){prefs.edit().putBoolean("first",false).apply();scheduleAll()}
 }
 private fun dayLabel(d:Any?)=when(d){is JSONArray->(0 until d.length()).joinToString(", "){d.getString(it)};else->d?.toString()?: ""}
 private fun scheduleAll(){events.forEachIndexed{i,e->scheduleEvent(i,e,prefs.getBoolean("e$i",true))}}
 private fun cancelAll(){events.indices.forEach{val pi=PendingIntent.getBroadcast(this,it,Intent(this,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);(getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)}}
 private fun scheduleEvent(i:Int,e:Event,on:Boolean){
  val am=getSystemService(ALARM_SERVICE) as AlarmManager
  val pi=PendingIntent.getBroadcast(this,i,Intent(this,ReminderReceiver::class.java).putExtra("name",e.name).putExtra("id",i),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  am.cancel(pi); if(!on)return
  val times=when(e.name){ "SnowBanshee"->listOf(27,57); "NemesisTyrant"->listOf(15,45); "SnowBanshee Soul"->listOf(0,30); else->listOfNotNull(e.time.takeIf{it.matches(Regex("\\\\d{2}:\\\\d{2}"))}?.let{LocalTime.parse(it).toSecondOfDay()/60}) }
  if(e.time=="All day"||e.time.contains("–"))return
  val days=when(val d=e.days){is JSONArray->(0 until d.length()).map{d.getString(it)};else-> emptyList()}
  val now=ZonedDateTime.now(ZoneId.of("Africa/Cairo"))
  var next:ZonedDateTime?=null
  for(offset in 0..8){val date=now.toLocalDate().plusDays(offset.toLong());val day=date.dayOfWeek.name.take(3).lowercase().replaceFirstChar{it.uppercase()}
   val eligible=days.isEmpty()||day in days||e.days=="Daily"||e.days=="Hourly"||(e.days=="First day of month"&&date.dayOfMonth==1)
   if(!eligible)continue
   for(minute in times){val t=date.atStartOfDay(ZoneId.of("Africa/Cairo")).plusMinutes((minute-5).toLong());if(t.isAfter(now)&& (next==null||t.isBefore(next)))next=t}
  }
  if(next!=null){val millis=next!!.toInstant().toEpochMilli();if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)}
 }
}
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val name=i.getStringExtra("name")?:"Conquer Event";val id=i.getIntExtra("id",0);val n=Notification.Builder(c,"events").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Conquer Events").setContentText("$name starts in 5 minutes!").setAutoCancel(true).setCategory(Notification.CATEGORY_EVENT).build();(c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id,n)}}
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){if(i.action==Intent.ACTION_BOOT_COMPLETED){val launch= c.packageManager.getLaunchIntentForPackage(c.packageName);launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(launch)}}}
